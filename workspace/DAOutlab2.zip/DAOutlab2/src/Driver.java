import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;

public class Driver {

	public static void main(String[] args) throws UnsupportedEncodingException, FileNotFoundException {
		// TODO Auto-generated method stub
		RiffRaff riff = new RiffRaff();
		riff.readIn();
	}

}
